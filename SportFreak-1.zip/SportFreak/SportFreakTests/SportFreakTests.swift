//
//  SportFreakTests.swift
//  SportFreakTests
//
//  Created by Srivardhan Bhogadi on 10/30/25.
//

import Testing
@testable import SportFreak

struct SportFreakTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
